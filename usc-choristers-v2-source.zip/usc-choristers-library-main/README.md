# USC Choristers — Music Library (front end)

A static, read-only catalogue of the choir's sheet music. Twenty folders circulate
between forty singers, two to a folder, so on any given night only one of each pair
can take the music home. This site is what lets the other one practise.

The site is public. The scores are not — they live in the choir's Google Drive and
are shared with a Google Group containing the members. A stranger who finds this
page sees a list of titles; clicking a score gets them "You need access."

---

## Running it

```bash
npm install
npm run dev      # http://localhost:4321
npm run build    # writes dist/
npm run preview  # serve dist/ locally
```

Node 18 or newer.

## Deploying

Cloudflare Pages, connected to this repository.

| Setting | Value |
| --- | --- |
| Build command | `npm run build` |
| Build output directory | `dist` |
| Node version | 18 or newer |

Nothing else is required. There are no environment variables, no API keys, and no
secrets in this repository — **keep it that way.** The repo is public. The deploy
hook URL in particular must never be committed; it belongs in the data-side tooling
that triggers rebuilds.

That tooling now exists. A Cloudflare **deploy hook** named `Catalog sheet` is called
by an Apps Script bound to the librarians' Google Sheet: it notices edits, waits until
the editing has stopped, and asks Cloudflare to rebuild. Roughly 6-11 minutes after a
librarian's last edit, production changes. You never touch it — but it means **the
site can change without anyone pushing a commit.** If production looks different from
your branch, that is why, and it is not a bug.

---

## The Apps Script

The automation described above is **not in this repository**, deliberately. It lives in
the Apps Script project bound to the librarians' Google Sheet, and that is its only copy.

**Why it isn't committed.** One of its files holds the Cloudflare deploy hook, and this
repo is public. But the deeper reason is the one that put the catalogue in a Sheet rather
than a JSON file: a copy here would drift from the live one the moment somebody edited it
in the Apps Script editor, and a second source of truth is worse than none.

**How to read it.** Ask the librarian. From the Sheet: **Extensions -> Apps Script**.
Anyone with edit access to the Sheet can read every line.

| File | What it does |
| --- | --- |
| `Code.gs` | Notices edits, waits for quiet, sorts the Catalog by title, calls the deploy hook. Holds the hook URL — **never copy this file anywhere public.** |
| `validation.gs` | Rebuilds every Catalog dropdown from the Vocabulary tab, matching columns by header name. `setupValidation()` after any column change; `auditValues()` reports off-vocabulary values. |
| `ocr.gs` | Converts each score PDF to a Google Doc to run Drive's OCR, storing title-block text on a "Score text" tab. This is where the composer and arranger data came from. |
| `pages.gs` | Reads the page count out of each score PDF and fills the Catalog's `pages` column, with a review tab in between. |

Access is gated by the Sheet, which is intentional: the script can trigger production
deploys. If you are a developer who wants to study or change it, that conversation starts
with the librarian, not with a pull request.

---

## Tabs and groupings

**In the folders** is the default and is **grouped by `occasion`** in a fixed
calendar order: Mass / Liturgy, Current Event, Christmas Concert, Amore, Affinity,
Independence Day Concert, Competition. This list mirrors the Occasion column on the
Sheet's Vocabulary tab and changes when the librarians change it. Empty
groups are skipped, and a header disappears when filtering empties it. With 50+
pieces in rotation this grouping does more work than any filter — a chorister knows
which concert they are preparing for.

**Concert tabs** — Current Event, Christmas, Amore, Independence Day, Competition — each show every piece for
that occasion, **including music still in the cabinet**, grouped into "In the
folders" and "Resting in the cabinet". Next Christmas's programme is partly not in
the folders yet, and that is precisely what a chorister and a librarian both need to
see. An empty group is skipped, so a concert with everything already in circulation
shows no cabinet heading at all.

**Current Event** is the rotating one. The choir prepares a different line-up for
whatever is next — Affinity week, a concert, a competition — and used to make a fresh
Drive folder each time. Instead, librarians retag that line-up as `Current Event` and
the tab follows them; the previous event's pieces go back to their permanent occasion.
It is the only occasion that is expected to churn.

Which occasions get a tab is one list, `CONCERT_TABS` in `src/lib/catalog.js`. The
name must match the `occasion` value in the Sheet exactly; a tab whose occasion has
no pieces is skipped automatically. Tab labels drop a trailing "Concert", since
repeating it five times just eats width on a phone.

**Full library** is everything, grouped alphabetically, mirroring how the cabinet is
physically filed.

There are three orderings — occasion, status and alphabetical — and each row and
header carries all three as `data-occ-order`, `data-stat-order` and
`data-lib-order`. Switching tabs **reorders the DOM** rather than using CSS `order`. That was the
obvious alternative and it is wrong here: `order` reorders what you see without
reordering focus, so a keyboard user would tab through rows in a different sequence
than the one on screen. Markup is emitted in occasion order so the default tab is
correct at first paint, before any JavaScript runs. Each element carries both
positions in `data-occ-order` and `data-lib-order`.

## The data contract

The **librarians' Google Sheet is the source of truth.** `src/lib/loadCatalog.js`
fetches it as published CSV at build time and hands the front end a catalogue object.
Nothing about this needs a key or a login: the Sheet is published to the web as CSV,
chosen precisely because there is no credential that can expire on a future librarian.

`src/data/pieces.json` is **the fallback, not the source.** It loads only when the
fetch fails — a bad network, an unpublished sheet, a renamed column — so the site
degrades to a slightly stale catalogue instead of going blank during concert week. It
is regenerated from the Sheet periodically. **Do not hand-edit it**; your changes will
be overwritten the next time it is refreshed.

Both paths produce the same shape, so you can develop against either. If your terminal
prints `[catalog] SHEET FETCH FAILED`, you are looking at the fallback — the numbers on
screen are real but old.

```json
{
  "generatedAt": "2026-08-20T09:14:00+08:00",
  "totalSets": 20,
  "pieces": [
    {
      "id": 1,
      "title": "Rosas Pandan",
      "subtitle": "",
      "composer": "Traditional (Cebuano)",
      "arranger": "George G. Hernandez",
      "voicing": "SATB",
      "accompaniment": "A cappella",
      "language": "Cebuano",
      "genre": "Filipino Folk",
      "occasion": "Independence Day Concert",
      "difficulty": "Medium",
      "durationMin": 3.0,
      "sets": 20,
      "scoreUrl": "https://drive.google.com/...",
      "minusOneUrl": null,
      "vocalGuideUrl": null,
      "inFolders": true,
      "lastPerformed": "2026-02-14"
    }
  ]
}
```

Assumptions this front end makes, which the generator must hold up:

- **`genre` and `occasion` are two separate fields.** Genre drives colour; occasion
  drives grouping on the folders tab.
- **`minusOneUrl` and `vocalGuideUrl` may be `null`.** Practice audio appears in
  three places, and every one of them renders only when the link exists, so nothing
  is ever a dead button: an inline link on the row itself, a "Practice" filter pair
  ("Has a minus one" / "Has vocal guides"), and a button in the drawer.
  `vocalGuideUrl` may point at a single file or at a Drive folder of per-part
  guides; it is treated as an opaque link and always labelled "Vocal guides".
- **Archived pieces and pieces without a score link are already excluded.** There is
  no filtering for them here, by design.
- `season` and `voicing` come from the Vocabulary sheet's controlled lists. A season
  outside the known list still renders — it just takes the graphite colour.
- `totalSets` drives the "N folder sets" figure in the header. Nothing is hardcoded.
- `generatedAt` drives the "Updated" date.
- `audioUrl` may be `null`; the drawer hides the recording button when it is.

If a field is renamed on the Sheet side, the two places to change here are
`src/components/Piece.astro` (which writes the data attributes) and the drawer
section of `src/pages/index.astro` (which reads them).

---

## How it is built

Astro, static output. **The entire catalogue is rendered to HTML at build time.**
The client script only shows and hides rows that are already on the page, so the
whole interactive layer is about 4.5 kB (1.7 kB gzipped) and the music is readable
the instant the page paints — which matters on a phone in a rehearsal hall.

```
src/
  data/pieces.json        the contract; replaced by the build step
  lib/catalog.js          season colours, ordering, formatting
  layouts/Base.astro      document shell, theme bootstrap
  components/             Masthead, Hero, Tabs, Controls, Toolbar, Piece, Drawer, Footer
  pages/index.astro       assembles the page + the client script
  styles/global.css       the whole design
public/fonts/             five self-hosted woff2 faces
```

### Two views, one DOM

The prototype rebuilt each row's `innerHTML` when switching between list and card
views. Here every row has a single markup shape and the two views are pure CSS —
list uses a four-column grid, cards use a two-by-two grid with the title area
spanning both columns. That is what makes build-time rendering possible. If you add
something to a row, add it to both view rules in `global.css`.

### Colour follows genre

Ten genres collapse onto seven colour families: violet Sacred; gold Christmas /
Carol; blue Classical / Art Music; teal Contemporary Choral; rust Filipino Folk and
OPM / Filipino Popular; rose Pop & Jazz and Musical Theatre; green Patriotic and
World & International Folk.

**Genre, not occasion.** Occasion only means something for music in current
rotation, so colouring by it would leave every cabinet piece grey and kill the
coding in the library view. Genre is permanent, so it survives into the cabinet.

**This is the only colour in the interface**, which is why the UI chrome is
monochrome — ink and parchment, no accent hue. An interface accent would collide
directly with blue = Classical, and the moment a second colour system appears the
first one stops meaning anything.

### Settings

A slide-over panel from the masthead. Five preferences, all per-device in
`localStorage` under `usc-settings`, all applied by an inline script in
`Base.astro` **before first paint** so nothing flashes:

| Setting | Options | Applied as |
| --- | --- | --- |
| Appearance | Dark / Light / Match device | `html[data-theme]` |
| Text size | Normal / Large / Largest | `html` root `font-size` |
| Row spacing | Comfortable / Compact | `--row-y` |
| Library view | List / Cards | initial view on the library tab |
| Animation | On / Reduced | `html[data-motion]` |

There is no separate Light/Dark button in the masthead. Two controls owning one
piece of state is how they drift apart. Theme is the first row in the panel.

"Match device" attaches a `matchMedia` listener, but only follows the device while
that option is selected — an explicit Dark or Light choice is never overridden.
`prefers-reduced-motion` is still honoured on its own; the Animation setting only
adds the ability to reduce motion when the OS isn't asking for it.

### The genre spectrum

The stacked bar under the title is the current tab's genre mix, drawn in the genre
colours already in use. It grows on load, re-proportions when the tab changes, and
each segment is a filter that stays in sync with the Genre chips. It is the one
place colour is spent expressively, and it earns it by carrying information.

Two things about it are load-bearing and easy to break:

- **`.spectrum` must not have `overflow:hidden`.** Each segment carries an invisible
  40px-tall hit area as a `::after`; clipping it leaves a 7px target that only
  registers a dead-centre click, which reads as "the filter is broken".
- **Segment colours come from the resolved chip value, not `var(--genre)`.**
  `getComputedStyle` resolves a custom property all the way to `#9b7ed0`, so
  re-wrapping it as `var(--#9b7ed0)` is invalid and the whole bar renders
  transparent — with correct widths, so it looks like nothing rendered at all.

### The rest of the visual language

- **Entries are ruled, not boxed.** A hairline between rows, and a short flag of
  genre colour in the left margin that grows to full height on hover. Boxes are
  reserved for the card view, where a card is genuinely the metaphor.
- **Octavo setting** in the card view. Voicing top-left in mono, composer flush
  right, title centred in serif under a hairline, catalogue number in a colophon at
  the foot.
- **Tabs are running heads**, underscored when current, rather than pills — quieter,
  and it survives a long occasion name on a phone.
- **Search is a ruled line**, not a boxed input.
- **Group headers.** Occasion headers on the folders tab carry a live count; letter
  headers on the library tab mirror the cabinet. Both hide themselves when nothing is
  filed under them.
- **Difficulty** is a three-dot meter, not a word and not a colour.
- **Quiet at rest.** Filters collapse behind one control at every width, not just on
  mobile. On the first screen: no chips, 23 bordered elements, 11 type sizes.
- **Motion explains, it does not decorate.** The tab underline slides so you see
  where you came from; the filter panel grows so you know where the chips went; rows
  arrive as you scroll to them; counts roll. The single ambient exception is the
  stave behind the title, drifting on a 90-second cycle.
- **Group headers are not sticky.** They were for one iteration and it was wrong:
  every header shares the one grid parent, so they stick independently and pile up
  at the top of the viewport instead of displacing each other. Fixing that needs a
  wrapper per group, which would break the flat-sibling DOM reordering that keeps
  focus order honest.
- **The staff motif** — the masthead mark and the rule across the hero — is drawn in
  CSS gradients. No images anywhere in this project.
- **Press grain.** A 3px radial-gradient tooth on the body, so neither theme reads as
  flat screen colour.

---

## The choir's emblem

Assets live in `public/brand/`, generated from the original logo PNG.

- **The masthead mark is a CSS mask, not an `<img>`** — `mask-image` over a
  `background: var(--text)`. It is painted in the current text colour, so it follows
  the theme with one asset and no second file.
- **It is monochrome on purpose.** The emblem's own gold (`#d89018`) and green
  (`#007800`) are almost exactly two of the seven genre colours. A gold mark sitting
  directly above a list where gold means Christmas would quietly undo the rule the
  whole design rests on. If you'd rather have it in colour, drop the mask and use
  `<img src="/brand/mark.png">` — but expect the colour system to read as decorative
  from that point on.
- **Full colour appears in the footer**, where nothing competes with it, and on the
  app icon.
- The class is `.emblem`, not `.mark` — `.mark` is already the empty state's glyph.

`site.webmanifest` plus the apple-touch icon make "Add to Home Screen" work properly:
standalone display, the dark page ground as the splash colour, and a maskable icon
so Android doesn't crop the laurel.

## The easter egg

"Meet the creators" in the footer opens two pinned portraits with a quote each.
It expands **in flow** rather than floating, so it cannot overflow a phone, and it
opens three ways: hover for a mouse, focus for a keyboard, and the button for a
finger. The hover rule is fenced behind `(hover:hover) and (pointer:fine)` — without
that, a phone would need a tap to open and a tap somewhere else to close it, which
is how hover menus become traps on touch.

The cards are horizontal — portrait left, words right. They were vertical first, with
a square photo at full card width, which made each card nearly a phone screen tall:
far too much room for a joke hidden in the footer.

**This is the only place on the site allowed its own colour.** The gold and green
come from the emblem, not the genre palette, and the footer is far from anything
semantic, so they cannot be misread as "Christmas" or "Patriotic". Do not let those
two variables — `--brand-gold`, `--brand-green` — near the list.

To change the names, photos or quotes, edit the `creators` array at the top of
`src/components/Footer.astro` and drop matching images in `public/brand/`.


## Iteration two

Built from `ROADMAP.md`. Everything in Section 1 and Section 2 except offline, plus
the safe half of Section 3.

### Deep links

`#p-42` opens piece 42. The drawer writes the hash when it opens and clears it when
it closes, so the back button behaves. A link **beats the remembered tab**: someone
following a shared link wants that piece, not wherever they were last time. If the
piece is not in the current tab, the view falls through to Full library and clears
any filters first — otherwise the link would open on an invisible row.

`Copy link to this piece` sits in the drawer. `navigator.clipboard` is refused on
insecure origins and inside some in-app browsers, so there is a `prompt()` fallback
that puts the URL somewhere it can be copied by hand.

### Starred pieces

localStorage only: no account, no backend, nothing to administer, nothing that can
expire. The cost is honest and stated in Settings — one browser, one device, gone if
that browser is cleared. Ids for pieces that no longer exist are **pruned on load**,
otherwise the tab would read "Starred 2" and open on nothing, which is
indistinguishable from a bug.

The Starred tab hides itself when empty, and unstarring the last piece moves you to
Full library rather than stranding you on an empty tab.

### Search

Two passes. Exact substring first, on a haystack folded at build time and a query
folded at run time, so `Fauré` and `Faure` are the same string. If that finds
nothing and the query is four characters or more, a **near-match pass** allows one
edit per word — an insertion, a deletion, a substitution or a transposition. The
count line says `near matches` so nobody thinks an exact result was found.

The roadmap's own example needed this: `Adeste Fideles` finding `Adeste Fidelis` is
a misspelling, not an accent, and folding alone never catches it. No title in the
catalogue carries a diacritic today, so the folding is future-proofing for the first
`Dvořák`.

### Printing

Prints whatever is on screen. Filter to a concert, press **Print list**. One
selection mechanism, so the list and the printout cannot disagree. The print
stylesheet forces the light palette regardless of theme — nobody wants a black page
out of a shared printer — and drops every piece of chrome.

### Themes

Sepia and High contrast join Dark, Light and Match device. All are **chrome-only**:
background, surfaces, text, borders. The seven genre hues are not touched, because a
theme with its own accent puts a second colour system on screen and the first stops
reading as information. Every theme is checked for six distinct genre colours and
for title contrast; the lowest is 13.5:1.

**Hero mode** is the novelty theme and is deliberately **not** in Settings. It lives
behind the easter egg in the footer. A maestro opening the preferences should not
find Ben 10 in the list; someone who went looking in the footer has earned it.

### Librarian tools

`/gaps` lists what is incomplete, one section per missing field, longest first. Not
linked from anywhere: choristers have no use for it and a tab called "Gaps" makes
the catalogue look unfinished to a visitor.

It also flags **columns that carry no information** — a field with the same value on
every row is a default that was filled down and never revisited. `difficulty` is
`Easy` on all 181 pieces today, which is why it no longer appears in the drawer.

## Mistakes already made in iteration two

Added to the list above, for the same reason.

**A control inside a row needs the guard in the row's own handler.** The star opened
the drawer, because `stopPropagation` in a delegated listener on `document` runs
*after* the row's own listener has already fired during bubbling. The check has to
be `if (e.target.closest("a, button")) return;` inside the row handler itself.

**A floating button must never cover a control.** Back to top covered the Score link
on desktop. It is docked **left** now: every control in a row (star, practice
glyphs, Score) sits at the right end, and the left gutter holds only the catalogue
number and the voicing, neither of which is clickable.

**Grid items default to `min-width: auto`.** A long unbreakable word sets a floor
the column cannot shrink below. Filipino compound titles do exactly that, and at
320px a row rendered 303px wide inside a 283px container and scrolled the whole page
sideways. `.piece > * { min-width: 0 }` plus `overflow-wrap: anywhere` on the text.

**A clipped panel is still in the tab order.** `grid-template-rows: 0fr` with
`overflow: hidden` hides the filter chips visually but leaves them focusable, so a
keyboard user landed on controls that are not on screen. Collapsed panels get
`visibility: hidden` with a transition delay so the open animation still runs.

**A group of related controls should be one tab stop.** Six spectrum segments plus
six tabs put the search box fifteen presses away. The spectrum is a roving tabindex
now: one stop, arrow keys to move within it.

## Screen sizes

Verified on phones (320–412px), tablets (768–1180px, both orientations) and desktop.

- **The stacked row starts at 700px, not 820px.** A 768px iPad portrait has ~690px of
  usable width; stacking a title, a meta line and a composer there was a phone layout
  on a tablet. Tablets now show 6–7 rows instead of 4.
- **Touch enhancements key off `any-pointer: coarse`, not `pointer: coarse`.** An iPad
  with a keyboard attached reports a *fine* pointer, but the screen is still a screen
  and fingers still use it. Mouse-only flourishes stay behind
  `(hover:hover) and (pointer:fine)`, so a hybrid device correctly gets both.
- **Landscape tablets are wide but short** — 768px tall on an iPad mini — so the hero
  tightens under `(min-width:701px) and (max-height:840px)`.
- **Past 1700px the page is capped and centred**, because the eye travelling from a
  title on the left to a composer on the right stops being a list and starts being a
  spreadsheet.

## Touch

The choir reads this on phones and tablets during rehearsal, standing, in dim light,
often one-handed. Everything that depended on a cursor is **replaced** under
`@media (hover:none),(pointer:coarse)`, not merely switched off:

| Mouse | Touch |
| --- | --- |
| Genre wash follows the cursor | Row flashes its genre colour under your thumb |
| Practice glyphs brighten on hover | Always legible, 40px targets |
| Card leans toward the pointer | Removed — nothing to lean toward |
| Hover reveals the genre name | Tap says it in words: "Sacred — showing 4" |
| — | Swipe left/right changes tab |

The swipe fires only on deliberate horizontal movement — over 70px across, under
50px vertical, within 600ms — so scrolling the list never changes tab.

**Never expand a tap target with an absolutely positioned `::after` inside a row.**
`.piece` is `position:relative`, so `inset:0` on a child pseudo-element expands that
child to cover the entire row. This shipped once: the Score link covered all
351×117px of the row, so every tap opened the PDF and the drawer was unreachable on
a phone. Use padding on the element itself.

**The chrome budget on phones.** Measured on a real device, the header stack was
~380px on *every* phone regardless of screen height — 60% of a 640-tall screen
before a single piece of music. It is now ~285px. What bought that back, in order
of value: the count row hides until it has something the tabs do not already say;
the ledger's last two figures drop below 640px and the whole ledger drops below
700px tall; the masthead, hero, tabs and group headers all tighten. If you add
anything above the list, measure the total first — the target is **3 rows visible
on a 360x640 phone**.

**The genre spectrum has to fit the viewport.** Ten segments at a 34px minimum need
367px, which overflowed a 360px phone and cut the last genres off the right edge.
Narrow screens use a 24px floor (258px total, fits a 320px phone) and lean on the
40px-tall hit area instead.

**The tab strip is wider than a phone**, so `moveSlider()` scrolls the selected tab
into view. Without it the page can open showing the last three tabs while the first
one is the active one, off-screen to the left.

**Close buttons need a z-index.** `.shead > *` sets `position:relative` on the panel
header's children, and the voicing line follows the ✕ in the DOM, so without an
explicit stacking order it paints over the button and swallows the tap.

## Things that will bite you

- **`[hidden]` loses to `display:grid` and `display:flex`.** The rule
  `[hidden]{display:none !important}` in `global.css` is load-bearing. Delete it and
  filtering silently stops working while the JavaScript keeps reporting correct
  counts.
- **Fonts are self-hosted on purpose.** Google's CDN is unreachable in some
  environments and the design falls back badly. Do not swap `public/fonts` for a
  `<link>` to fonts.googleapis.com.
- **Fifteen season chips do not fit on a 390px screen.** Below 700px the filter panel
  collapses behind a toggle with an active-count badge. Rendering them inline pushed
  every result below the fold. This was hit once already; the media query at the
  bottom of `global.css` is the fix.
- **The repository is public.** No keys, no deploy hooks, no member names.
- **`CONCERT_TABS` strings must match the Sheet exactly.** A tab exists only if
  `pieces.some(p => p.occasion === o)` — strict equality. The label you see is that
  string with a trailing `" Concert"` stripped, so the *Christmas* tab requires the
  occasion to be `Christmas Concert`; `Christmas` on its own renders no tab at all.
  This cost an afternoon of debugging once. The tab label is cosmetic, the occasion
  string is load-bearing, and they are not the same thing.
- **The vocabulary lives in the Sheet, not here.** `OCCASION_ORDER` and `GENRE_ORDER`
  mirror the Vocabulary tab. Adding a value here does nothing until a librarian tags
  pieces with that exact string — and if they add one and nobody mirrors it here, those
  pieces vanish from the folders grouping while still appearing in the full library.
- **The drawer reads the DOM, not the catalogue.** `Piece.astro` writes every field
  onto the row as a `data-` attribute and `openDrawer` reads them back off
  `el.dataset`, so the page never ships a second copy of the catalogue as JSON.
  Adding or removing a field means changing it in *both* places — the attribute in
  `Piece.astro` and the row in the `facts` array in `index.astro`.
  Removing is the forgiving direction: delete the helper in `catalog.js` without
  doing both and the build fails on a missing export.
  **Adding is the dangerous one, because it fails silently.** Put a row in `facts`
  without the matching `data-` attribute and `d.yourField` is `undefined`, so every
  piece renders an em dash and the build says nothing at all. This has now happened
  twice, with `formation` and with `pages`. **If a new field shows as `—` for every
  single piece, the attribute is missing from `Piece.astro`.**
- **Write a `data-` attribute as `p.field ?? ""`, never `String(p.field)`.**
  `String(null)` is the literal text `"null"`, which is why `data-sets` needs a
  `d.sets !== "null"` guard in the drawer to avoid rendering "null sets". An empty
  string is falsy, so `|| "—"` handles a missing value with no special case. The
  guard on `sets` is a workaround for a bug, not a pattern to copy.

## Decisions that are settled

Do not re-propose these; each was chosen for a reason that still holds.

- **Google Sheet as the CMS**, not an admin panel. Future librarians have no coding
  knowledge and an admin panel is a permanent maintenance burden they cannot fix.
- **PDFs linked from Drive, never uploaded through the app.** Google OAuth apps in
  Testing status get refresh tokens that expire after seven days, and escaping that
  needs Google's verification process. Librarians upload by hand through the Drive
  UI. There is deliberately no upload feature.
- **No database.** Supabase free projects pause after seven days of inactivity and
  need a manual dashboard unpause, which is fatal for a tool used a few times a
  semester.
- **No GitHub Actions cron.** Scheduled workflows are auto-disabled after 60 days of
  repository inactivity.
- **Public site plus Drive-group permissions**, not a login on the site. Cloudflare
  Access caps at 50 seats on the free tier and holds seats until manually removed;
  forty members plus an annual intake blows past that within two years. Removing a
  graduating batch here is one edit to the Google Group.
- **Cloudflare Pages over Netlify** — Netlify's free tier cannot password-protect a
  site, and Pages costs nothing.
- **Astro over Next.js** — ships almost no JavaScript, and this is used on phones.
- **One site for members.** Librarians work in the Sheet. There is no librarian UI
  and no admin interface to build.

---

## Still open

- Which Google account owns the Drive folder and the Sheet has not been decided.
  Whichever it is, **the 2FA recovery number must not belong to a graduating
  student.** This is the single biggest risk to the project outliving its builders.
- The pieces × folders inventory grid (10 active pieces × 20 folders, marking each
  present, missing or damaged) is deferred and belongs to the data side, not here.
