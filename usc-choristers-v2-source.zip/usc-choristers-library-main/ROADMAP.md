# USC Choristers Music Library — Ideas for iteration two

> **Status, end of iteration two.** Everything in Section 1 is done. Everything in
> Section 2 is done except offline, which was deliberately left (see below).
> Section 3 is done as chrome-only themes plus the novelty theme behind the easter
> egg. Section 4 stands untouched. What follows is the original menu, kept because
> the reasoning still applies to whatever comes next.
>
> | Item | State |
> | --- | --- |
> | Back to top | Done — docked left, so it never covers a Score link |
> | Link straight to one piece | Done — `#p-42`, beats the remembered tab |
> | Copy link button | Done — with a fallback for refused clipboard access |
> | Remember the last tab | Done |
> | A–Z jump strip | Done — one scrolling row, not three wrapped ones |
> | Personal favourites | Done — localStorage, phantom ids pruned on load |
> | Works offline | **Not done, on purpose.** The scores live in Drive and cannot be cached. Offline gets you the catalogue, not the music, and presenting it as "the library in your pocket" would annoy people at a rehearsal. Still worth building if someone wants it — the honest caveat is already written below. |
> | Printable set list | Done — prints the current filtered view |
> | Search that ignores accents | Done, **and** a near-match pass. The example in this document is a misspelling, not an accent; folding alone never catches it |
> | A gaps view for librarians | Done — `/gaps`, unlinked |
> | Themes | Done — Sepia and High contrast in Settings, Hero mode behind the easter egg |
>
> The next thing worth doing is not on this list: **fill `difficulty` or delete it.**
> It is `Easy` on all 181 pieces, which is a default, not data. `/gaps` flags it.


A list of things the site could become, written at the end of iteration one so that whoever picks this up next has somewhere to start. **Nothing here is required.** The site works. This is a menu, not a backlog.

Each item is tagged **value** (to a chorister, not to a developer) and **effort** (rough — a weekend is "medium").

---

## Before anything else: the three constraints

Every idea below was checked against these. If you have an idea of your own, check it against these too — and if it fails one, it isn't a good idea for *this* site, however good it is in general.

1. **Free forever.** No paid tiers, no trials, nothing with a card attached. The moment this costs money it dies the term after nobody remembers to pay.
2. **Maintainable by a non-coder.** Adding a piece, a genre, an event must never require touching code. Anything that puts a librarian in a text editor is a regression.
3. **It must outlive whoever builds it.** No credential that expires, no service that pauses inactive projects, no dependency on one person's account.

There is a fourth, softer one worth knowing about:

4. **Colour means genre, and nothing else.** See §4.

---

## 1. Quick wins — high value, small effort

**Back to top button** · value: high · effort: tiny
183 pieces is a long scroll. A floating button appearing after the first screenful, disappearing at the top. Give it `position: fixed`, a decent tap target (44px minimum), and make sure it doesn't cover the last row on a small phone.

**Link straight to one piece** · value: high · effort: small
Right now a piece's drawer opens client-side and leaves no trace in the URL. Put the piece id in the hash — `#p-42` — and read it on load. Suddenly a section leader can paste "learn this one" into the group chat and it opens on the right song. This is probably the single highest-value item on the whole list, because it turns the site into something people send each other rather than something they browse alone.

**Copy link button in the drawer** · value: medium · effort: tiny
Pairs with the above. One button, `navigator.clipboard.writeText`, brief "Copied" confirmation. Useless without the hash routing; do them together.

**Press `/` to search** · value: medium · effort: tiny
Focus the search box from anywhere. Standard on every site with a search box. Remember to ignore the shortcut when focus is already in an input, or people typing a slash in a title will jump around.

**Remember the last tab** · value: medium · effort: small
Store the selected tab in `localStorage` and restore it on load. A chorister rehearsing for Christmas lands on Christmas every time instead of re-picking the tab daily.

**A–Z jump strip in Full library** · value: medium · effort: small
The library is already grouped by shelf letter. A row of letters that scroll-jumps to the group would make 183 pieces feel like a real cabinet. Skip letters with no pieces.

---

## 2. Worth doing properly

**Personal favourites** · value: high · effort: medium
Let someone star pieces and see just those. Done entirely in `localStorage` — no accounts, no backend, no login, nothing to maintain. Constraint 1 and 3 stay intact. The catch: it lives in one browser on one device and vanishes if they clear their data. That's an acceptable trade for a practice list; say so in the UI so nobody is surprised.

**Works offline** · value: high · effort: medium-high
Rehearsal venues have bad signal. A service worker caching the built pages would let the catalogue open with no connection at all.

**Be honest about the limit before you build this:** the scores themselves live in Google Drive and cannot be cached. Offline gets you the *catalogue* — titles, composers, what's in the folders — not the music. That's still worth having, but it isn't "the library in your pocket", and if you present it as that people will be annoyed at a rehearsal.

**Printable set list** · value: medium · effort: medium
Tick pieces, get a clean printable page — title, composer, formation, page count. The librarian currently rebuilds this by hand for every concert. A `@media print` stylesheet does most of the work.

**Search that ignores accents** · value: medium · effort: small
Someone searching "Adeste Fideles" should find "Adeste Fidelis"; someone typing "Panalangin" without the diacritic should still land. Normalise both the haystack and the query with `.normalize("NFD").replace(/\p{Diacritic}/gu, "")`.

**A gaps view for librarians** · value: low to a chorister, high to a librarian · effort: medium
One screen showing what's incomplete: pieces with no composer, no minus one, no page count, no formation. It turns "the catalogue is never finished" into a visible, shrinking list. Could be a hidden URL rather than a tab — it's a maintenance tool, not a feature.

---

## 3. Themes

You asked for these specifically, so here's the real answer, including the part that will bite you.

**How it would work:** the site already has dark and light driven by CSS custom properties. A theme system is the same mechanism with more names — `data-theme="pink"` on `<html>`, a block of variable overrides per theme, a picker somewhere quiet, the choice saved to `localStorage`. Low risk, moderate CSS work, no build changes.

**The part that will bite you:** genre colour is the only colour in this interface, and that's deliberate — it's what makes the colours *mean* something. A theme that introduces its own accent hue puts a second colour system on screen, and the moment there are two, the first one stops reading as information and starts reading as decoration. That's not a style opinion; it's the reason the chrome is monochrome in the first place.

So there are exactly two safe kinds of theme:

**Chrome-only themes** — change background, surfaces, text, borders. Leave the seven genre hues alone. Cheap, safe, and most of what people actually want. *Pink* is this. So is sepia, high-contrast, and a warmer or cooler dark.

**Full palette swaps** — redefine all seven genre hues *together*, as a coherent set, along with the chrome. More work, and each set needs checking for contrast, but this is where something like *Aurora* would live: cool greens and violets across the whole system rather than a single accent bolted on. Done well it's genuinely striking. Done half-way it makes two genres indistinguishable, so check every pair.

**Novelty themes — Ben 10 and friends.** Put them behind the easter egg, not in the main picker. The footer already has that culture; a joke theme belongs in the same drawer as the pinned portraits, found by people who go looking. Keeping it out of the main settings is what stops the site feeling unserious to a maestro or a visiting conductor, while still letting it be fun.

**Whatever you build, test every theme against the genre chips.** A theme where two genres read as the same colour has silently broken the one piece of information the colour system carries. Contrast-check the text on every chip too, in both light and dark.

---

## 4. Things not to do

Not because they're bad ideas — because they break a constraint, and the constraints are what make this thing survive.

**Accounts and logins.** Breaks constraint 2 (someone has to administer them) and constraint 3 (password resets need a live human). Everything personal can be done in `localStorage` without any of it.

**A real database.** The Sheet *is* the database, and its superpower is that a librarian who has never seen a terminal can edit it. Any database is a downgrade on the only axis that matters here.

**Comments, ratings, or requests on pieces.** Every one of those is a moderation job for a volunteer who didn't sign up for it, forever.

**A custom domain.** Recurring cost, annual renewal, dies quietly when someone forgets. Rename the Cloudflare Pages project if the URL bothers you — that's free and permanent.

**Uploading scores through the website.** Needs a backend and a credential that can expire. Drive already does this, and the librarian is already in Drive.

**Anything with an API key.** If it can expire, be revoked, or be tied to one person's account, it will eventually take the site down on a day nobody is looking. The published-CSV approach was chosen precisely because it has no credential at all.

---

## 5. If you're the one picking this up

Read `README.md` first — it explains the whole architecture and, more usefully, the section called "Things that will bite you", which is a list of mistakes already made so you don't have to repeat them.

**Start with the hash routing (§1).** It's small, it's self-contained, it touches the client script and nothing else, and it's the best way to learn how the drawer works before you change anything that matters.

**Don't undo these without understanding why they're there:**

- The build reads the Sheet, but falls back to a committed `pieces.json` if the fetch fails. That's what keeps a Google outage from breaking a deploy.
- Every column is matched by *header name*, never by position, in all four places that read the Sheet. That's what makes the Sheet safe for a librarian to rearrange.
- The rebuild waits six minutes after the last edit. That's not laziness — Google serves a cached copy of a published Sheet for about five minutes, so a faster rebuild reads stale data.
- Colour follows genre, and it's the only colour. See §3.

And keep the guide honest. If you change how something works, the librarian's guide is now wrong, and a wrong guide is worse than none.
